from django.apps import AppConfig


class FinancialCoreConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "financial_core"
    verbose_name = "Financial Core"

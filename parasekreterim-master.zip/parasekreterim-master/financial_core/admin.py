from django.contrib import admin
# Soyut modeller doğrudan admin'e kaydedilmediği için boş bırakıyoruz

# Register your models here.
